#include <ti/devices/msp432p4xx/inc/msp.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <ti/grlib/grlib.h>
#include <ti/devices/msp432p4xx/driverlib/gpio.h>
#include <ti/devices/msp432p4xx/driverlib/debug.h>
#include <ti/devices/msp432p4xx/driverlib/i2c.h>
#include <ti/devices/msp432p4xx/driverlib/interrupt.h>
#include "LcdDriver/Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "I2C_file.h"
Graphics_Context g_sContext;
// Don't edit the above part


// RTC - interrupt handler
/*char string1[20];
void RTC_C_IRQHandler(void){

    int seconds, minutes, hours;
    char string[20];
    seconds = ((RTCSEC >> 4) * 10) + (RTCSEC & 0x0F);
    minutes = ((RTCMIN >> 4) * 10) + (RTCMIN & 0x0F);
    hours = ((RTCHOUR >> 4) * 10) + (RTCHOUR & 0x0F);
    sprintf(string, "%02d : %02d : %02d", hours, minutes, seconds);
    Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        AUTO_STRING_LENGTH,
                                        48,
                                        90,
                                        OPAQUE_TEXT);
    RTCCTL0_L &= ~(RTCTEVIFG);
}
*/

//------------------------------------------------------------------------
// For LUX sensor

float lux;
void delay(unsigned long iter) {
    volatile unsigned long i;
    for (i = 0; i < iter; i++) {
        // Do nothing
    }
}
void myTone(uint16_t frequency, uint16_t duration)
{ // input parameters: Arduino pin number, frequency in Hz, duration in milliseconds
  unsigned long halfPeriod= 1000000L/frequency/2;
  int i =0;
while(i<100){
              P2->OUT |= BIT7;
              delay(halfPeriod);
              P2->OUT &= ~BIT7;
              delay(halfPeriod);
              i+=1;
}

}

// ADC results buffer /
static uint16_t resultsBuffer[2];

//----------------------------------------------------------------------------------------
int main(void) {
    // Stop watchdog timer
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;
    P1->DIR |= BIT0; //LUX LED PIN
    // Set P2.0 as output (LED)
    P2->DIR |= BIT0;
    P2->DIR |= BIT2;
    P2->DIR |= BIT7;

    // Set P1.1 as input (Button)
    P1->DIR &= ~BIT1;
    P1->REN |= BIT1; // Enable pull-up/pull-down resistor
    P1->OUT |= BIT1; // Select pull-up resistor
    //GPIO explanation
    P2->OUT &= ~BIT2;

   /* P1DIR = 0x00;
    P2DIR = 0x01;
    P2OUT = 0x00;
    P2REN = 0x00;
    P1REN = 0x02;
    while(1){
        if ((P1IN & 0x02) == 0x00){
            __delay_cycles(1000);
            if ((P1IN & 0x02) == 0x00){
               P2OUT ^= 0x01;
            }
            }
        else{
            P2OUT = 0x00;
        }
    }*/


    //------ RTC example ------

    RTCCTL0_H = RTCKEY_H;
    RTCCTL0_L |= RTCTEVIE;
    RTCCTL0_L &= ~(RTCTEVIFG);
    RTCCTL1 = RTCBCD | RTCHOLD;

    RTCYEAR = 0x2024;
    RTCMON = 0x03;
    RTCADAY = 0x13;
    RTCDOW = 0x03;
    RTCHOUR = 0x07;
    RTCMIN = 0x00;
    RTCSEC = 0x00;

    RTCCTL1 &= ~(RTCHOLD);

    RTCCTL0_H = 0;
    /*Crystalfontz128x128_Init();
    Crystalfontz128x128_SetOrientation(0);
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_RED);
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE);
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);
    Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)"Time",
                                        AUTO_STRING_LENGTH,
                                        64,
                                        30,
                                        OPAQUE_TEXT);
    */
    /*NVIC_EnableIRQ(RTC_C_IRQn);

    __enable_irq();
    __sleep();*/
    //while(1){
   // }


    // I2C example

    MAP_Interrupt_disableMaster();

    // Set the core voltage level to VCORE1
    MAP_PCM_setCoreVoltageLevel(PCM_VCORE1);
    Init_I2C_GPIO();
    I2C_init();
    OPT3001_init();
    __delay_cycles(100000);


//END OF LUX
//-------------------------------------------------------------------------------

    // JoySTICK
    // Halting WDT and disabling master interrupts
    MAP_WDT_A_holdTimer();
    MAP_Interrupt_disableMaster();

    // Set the core voltage level to VCORE1
    MAP_PCM_setCoreVoltageLevel(PCM_VCORE1);

    // Set 2 flash wait states for Flash bank 0 and 1
    MAP_FlashCtl_setWaitState(FLASH_BANK0, 2);
    MAP_FlashCtl_setWaitState(FLASH_BANK1, 2);

    // Initializes Clock System
    MAP_CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);
    MAP_CS_initClockSignal(CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    MAP_CS_initClockSignal(CS_HSMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    MAP_CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    MAP_CS_initClockSignal(CS_ACLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);

    // Initializes display
    Crystalfontz128x128_Init();

    // Set default screen orientation
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);

    // Initializes graphics context
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_RED);
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE);
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);
    Graphics_drawStringCentered(&g_sContext,
                                    (int8_t *)"Joystick:",
                                    AUTO_STRING_LENGTH,
                                    64,
                                    30,
                                    OPAQUE_TEXT);
    Graphics_drawStringCentered(&g_sContext,
                                (int8_t *)"Time:",
                                AUTO_STRING_LENGTH,
                                15,
                                7,
                                OPAQUE_TEXT);

    // Configures Pin 6.0 and 4.4 as ADC input
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P6, GPIO_PIN0, GPIO_TERTIARY_MODULE_FUNCTION);
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN4, GPIO_TERTIARY_MODULE_FUNCTION);

    // Initializing ADC (ADCOSC/64/8)
    MAP_ADC14_enableModule();
    MAP_ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_64, ADC_DIVIDER_8, 0);

    // Configuring ADC Memory (ADC_MEM0 - ADC_MEM1 (A15, A9)  with repeat)
     //    * with internal 2.5v reference
    MAP_ADC14_configureMultiSequenceMode(ADC_MEM0, ADC_MEM1, true);
    MAP_ADC14_configureConversionMemory(ADC_MEM0,
            ADC_VREFPOS_AVCC_VREFNEG_VSS,
            ADC_INPUT_A15, ADC_NONDIFFERENTIAL_INPUTS);

    MAP_ADC14_configureConversionMemory(ADC_MEM1,
            ADC_VREFPOS_AVCC_VREFNEG_VSS,
            ADC_INPUT_A9, ADC_NONDIFFERENTIAL_INPUTS);

    //Enabling the interrupt when a conversion on channel 1 (end of sequence)
    // *  is complete and enabling conversions
    //MAP_ADC14_enableInterrupt(ADC_INT1);

    // Enabling Interrupts
    //MAP_Interrupt_enableInterrupt(INT_ADC14);
    //MAP_Interrupt_enableMaster();

    // Setting up the sample timer to automatically step through the sequence convert.

    MAP_ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);

    // Triggering the start of the sample
    MAP_ADC14_enableConversion();
    MAP_ADC14_toggleConversionTrigger();


/*//lux lcd
    Crystalfontz128x128_Init();

    // Set default screen orientation
    Crystalfontz128x128_SetOrientation(0);
    // Initializes graphics context
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_RED);
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE);
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);
    */
    while(1)
    {
        //MAP_PCM_gotoLPM0();
        lux = OPT3001_getLux();
        if(lux<5){

            if(!(P1->IN & (1<<0))){
            unsigned long halfPeriod= 1000000L/1000/2;

                while(1){
                    int i =0;
              while(i<2000){
                            P2->OUT |= BIT7;
                            delay(halfPeriod);
                            P2->OUT &= ~BIT7;
                            delay(halfPeriod);
                            i+=1;}delay(1000);break;}}
            P1->OUT |= BIT0;

        }else{P1->OUT &= ~BIT0;}
        if ((P1->IN & BIT1) == 0) {
                    // Button is pressed, turn on LED
                    P2->OUT ^= BIT0;
                }
        char string[20];
        sprintf(string, "%f", lux);
        Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        6,
                                        48,
                                        120,
                                        OPAQUE_TEXT);

        sprintf(string, "lux");
        Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        3,
                                        86,
                                        120,
                                        OPAQUE_TEXT);
        /* Store ADC14 conversion results */
                resultsBuffer[0] = ADC14_getResult(ADC_MEM0);
                resultsBuffer[1] = ADC14_getResult(ADC_MEM1);


                sprintf(string, "X: %5d", resultsBuffer[0]);
                Graphics_drawStringCentered(&g_sContext,
                                                (int8_t *)string,
                                                8,
                                                64,
                                                50,
                                                OPAQUE_TEXT);

                sprintf(string, "Y: %5d", resultsBuffer[1]);
                Graphics_drawStringCentered(&g_sContext,
                                                (int8_t *)string,
                                                8,
                                                64,
                                                70,
                                                OPAQUE_TEXT);

                /* Determine if JoyStick button is pressed */
                int buttonPressed = 0;
                if (!(P4IN & GPIO_PIN1))
                    buttonPressed = 1;

                sprintf(string, "Button: %d", buttonPressed);
                Graphics_drawStringCentered(&g_sContext,
                                                (int8_t *)string,
                                                AUTO_STRING_LENGTH,
                                                64,
                                                90,
                                                OPAQUE_TEXT);
                int seconds, minutes, hours;
                seconds = ((RTCSEC >> 4) * 10) + (RTCSEC & 0x0F);
                minutes = ((RTCMIN >> 4) * 10) + (RTCMIN & 0x0F);
                hours = ((RTCHOUR >> 4) * 10) + (RTCHOUR & 0x0F);
                sprintf(string, "%02d : %02d : %02d", hours, minutes, seconds);
                Graphics_drawStringCentered(&g_sContext,
                                                    (int8_t *)string,
                                                    AUTO_STRING_LENGTH,
                                                    70,
                                                    7,
                                                    OPAQUE_TEXT);


                if (minutes == 1){
                    P2->OUT |= BIT2;
                }
                else if (minutes == 2){
                    P2->OUT &= ~BIT2;
                }

    }


}

/* This interrupt is fired whenever a conversion is completed and placed in
 * ADC_MEM1. This signals the end of conversion and the results array is
 * grabbed and placed in resultsBuffer */
/*
void ADC14_IRQHandler(void)
{
    uint64_t status;

    status = MAP_ADC14_getEnabledInterruptStatus();
    MAP_ADC14_clearInterruptFlag(status);

    // ADC_MEM1 conversion completed
    if(status & ADC_INT1)
    {
        // Store ADC14 conversion results
        resultsBuffer[0] = ADC14_getResult(ADC_MEM0);
        resultsBuffer[1] = ADC14_getResult(ADC_MEM1);

        char string[10];
        sprintf(string, "X: %5d", resultsBuffer[0]);
        Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        8,
                                        64,
                                        50,
                                        OPAQUE_TEXT);

        sprintf(string, "Y: %5d", resultsBuffer[1]);
        Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        8,
                                        64,
                                        70,
                                        OPAQUE_TEXT);

        // Determine if JoyStick button is pressed
        int buttonPressed = 0;
        if (!(P4IN & GPIO_PIN1))
            buttonPressed = 1;

        sprintf(string, "Button: %d", buttonPressed);
        Graphics_drawStringCentered(&g_sContext,
                                        (int8_t *)string,
                                        AUTO_STRING_LENGTH,
                                        64,
                                        90,
                                        OPAQUE_TEXT);
    }
}
*/




